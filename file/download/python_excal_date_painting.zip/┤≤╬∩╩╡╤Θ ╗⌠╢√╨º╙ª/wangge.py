
from matplotlib import pyplot as plt
def wang(xmin,xmax,ymin,ymax,wei):
    ax = plt.axes() #[xmin,ymin,xmax,ymax]
    ax = plt.figure.add_subplot(111)
    ax.set_xlim(xmin,xmax)
    ax.set_ylim(ymin,ymax)
    ax.xaxis.set_major_locator(plt.MultipleLocator((xmax-xmin)/20))#设置x主坐标间隔 1
    ax.yaxis.set_major_locator(plt.MultipleLocator((ymax-ymin)/20))#设置y主坐标间隔 1
    ax.grid(which='major', axis='x', linewidth=0.75, linestyle='-', color='0.75')#由每个x主坐标出发对x主坐标画垂直于x轴的线段
    ax.grid(which='minor', axis='x', linewidth=0.25, linestyle='-', color='0.75')#由每个x主坐标出发对x主坐标画垂直于x轴的线段
    ax.grid(which='major', axis='y', linewidth=0.75, linestyle='-', color='0.75')
    ax.grid(which='minor', axis='y', linewidth=0.25, linestyle='-', color='0.75')
    ax.set_xticklabels([])#标记x轴主坐标的值,在这里设为空值，则表示坐标无数值标定；其他情况如
    ax.set_yticklabels([])