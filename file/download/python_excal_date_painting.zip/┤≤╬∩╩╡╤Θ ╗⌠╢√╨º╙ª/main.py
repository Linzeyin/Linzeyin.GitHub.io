import xlwings as xw # 载入
import numpy as np # 载入
from matplotlib import pyplot as plt
from wangge import wang
from date import dateing
def f_fit(x,y_fit):
    a,b=y_fit.tolist()
    return a*x+b
def pic(xx,yy,Xlabel,Ylabel,shi,wei1,wei2,wei3):
    plt.subplot(wei1,wei2,wei3)
    wei=wei1+wei2+wei3
    print(wei)
    #wang(0,xx+10,0,yy+10,wei)
    plt.grid(True)
    plt.scatter(xx,yy,c='g',label='before_fitting')#散点图
    plt.plot(xx,yy,'b--',label='fitting')
    plt.title(shi)
    plt.xlabel(Xlabel)
    plt.ylabel(Ylabel)
    plt.legend()#显示标签

a=dateing(6,6,2,9,'data.xls',0)
d=np.linspace(1,4.5,8)
x1=np.array(d)
y1=np.array(a)
y1_fit=np.polyfit(x1,y1,1)#线性函数拟合
y1_show=np.poly1d(y1_fit)#函数优美的形式
y1=f_fit(x1,y1_fit)

a=dateing(16,16,2,9,'data.xls',0)
d=np.linspace(100,800,8)
x2=np.array(d)
y2=np.array(a)
y2_fit=np.polyfit(x2,y2,1)#线性函数拟合
y2_show=np.poly1d(y2_fit)#函数优美的形式
y2=f_fit(x2,y2_fit)


a=dateing(24,24,2,10,'data.xls',0)
d=np.linspace(100,900,9)
x3=np.array(d)
y3=np.array(a)
y3_fit=np.polyfit(x3,y3,1)#线性函数拟合
y3_show=np.poly1d(y3_fit)#函数优美的形式
y3=f_fit(x3,y3_fit)


pic(x1,y1,'Is','U',y1_show,3,1,1)
pic(x2,y2,'Im','U',y2_show,3,1,2)
pic(x3,y3,'Im','U',y3_show,3,1,3)

plt.show()