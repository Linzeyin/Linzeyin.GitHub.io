import numpy as np # 载入
def Xu(start,end,ep):#保证start和end中间间隔整数个ep
    ss = (int)(start/ep)
    ee= (int)(end/ep)
    a = range(ss,ee)
    b=[]
    for i in a:
        b.append(i*ep)
Xu(0.1,0.5,0.01)