import xlwings as xw # 载入
import numpy as np # 载入

def dateing(hangmin,hangmax,liemin,liemax,datename,sheetnum):
    wb = xw.Book(datename)# 打开excal文档
    sht = wb.sheets[sheetnum] # 选择所需操作的sheet
    a=[]
    for i in range(liemin,liemax+1) : # 取1到12列
        Row=chr(i+ord('a')-1)
        for j in range(hangmin,hangmax+1) :
            Range=str(j)
            b = sht[Row+Range].value # sht[X]中X格式为‘字母+数字’，如‘B7’
            a.append(b)
    #print(a)
    return a
#dateing(2,6,2,8,'data.xls',0)